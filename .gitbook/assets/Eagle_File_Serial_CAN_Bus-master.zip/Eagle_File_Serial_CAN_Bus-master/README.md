![](https://www.longan-labs.cc/media/wysiwyg/Categories/Categories-31.png)

Eagle file of [Serial CAN Bus Module](https://www.longan-labs.cc/1030001.html)

Click on [Longan-Labs.cc](https://www.longan-labs.cc/) to get the product you need.

Contact [support@longan-labs.cc](support@longan-labs.cc) if you need help.

[![Analytics](https://ga-beacon.appspot.com/UA-101965714-1/Eagle_File_Serial_CAN_Bus)](https://github.com/igrigorik/ga-beacon)
