[![](https://www.longan-labs.cc/media/wysiwyg/Categories/Categories-42.png)](https://longan-labs.cc)

Demo for getting data from OBD-II using [Wio Terminal](https://www.seeedstudio.com/Wio-Terminal-p-4509.html) and [Serial CAN Bus module](https://www.longan-labs.cc/1030002.html)

More details please go to [Hackster.io](https://www.hackster.io/longan_labs/hack-your-car-with-wio-terminal-and-can-bus-c6ddf4)

Click on [Longan-Labs.cc](Longan-Labs.cc) to get the product you need.

Contact [support@longan-labs.cc](support@longan-labs.cc) if you need help.

[![Analytics](https://ga-beacon.appspot.com/UA-101965714-1/OBD-II-Demo-x-Wio-Terminal)](https://github.com/igrigorik/ga-beacon)
